#ifndef BOT
#define BOT

// Место для ваших include
#include "TypesAndConsts.h"

// Некоторая тёмная магия, необходимая для того, чтобы ваш код успешно подключался к профайлеру.
// Отправлять эту часть на проверку или добавлять к другим профайлерам не надо.
// Также совершенно не обязательно понимать, что тут написано (я и сам не до конца понимаю).
// Просто воспользуйтесь главным правилом инженера: работает - не трогай.
#ifdef __cplusplus
extern "C" {
#endif

__declspec(dllexport) Point __stdcall shoot(ShotResult previousShot);
__declspec(dllexport) void __stdcall deploy(char field[][FIELD_SIZE]);

#ifdef __cplusplus
} // extern "C"
#endif

// Конец тёмной магии. Дальше можете писать код, как вы привыкли

Point shoot(ShotResult previousShot) {
    return {0, 0};
}

void deploy(char field[][FIELD_SIZE]) {
    
}

#endif // BOT
